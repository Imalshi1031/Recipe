import { Link,Route, Routes }from "react-router-dom";
import {Home} from "./pages/Home";
import {AddRecipe } from "./pages/AddRecipe";
import './App.css';

 function App() {
  return (
  <> 
  <nav>
    <ul>
      <li>
        <Link to ="/">Home</Link>
      </li>
      <li>
        <Link to ="/recipes">AddRecipe</Link>
      </li>
    </ul>
    
  </nav> 
  <Routes>
     <Route path="/" element={<Home />}/>
     <Route path="/recipes" element={<AddRecipe />}/>
     <Route path="/recipes/:id" element={<AddRecipe/>}/> 
   </Routes> 
  </> 
  )

 }

export default App;
 