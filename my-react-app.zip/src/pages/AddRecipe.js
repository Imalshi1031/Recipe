import {Link} from "react-router-dom"

export function AddRecipe (){
    return (
        <>
        <h1>AddRecipe</h1>

        <Link to = "/recipes/1">Recipe 1</Link> <br></br>
        <Link to = "/recipes/2">Recipe 2 </Link>
    
        </>
    
    ) 
} 