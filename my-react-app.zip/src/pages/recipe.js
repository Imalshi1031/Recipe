"use client"
import { useParams } from "react-router-dom"

export function Recipe () {
    const {id} = useParams()
    return <h1> Recipe {id}</h1>

}