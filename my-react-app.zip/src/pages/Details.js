export function Details (){
    return <h1>Details</h1>
}